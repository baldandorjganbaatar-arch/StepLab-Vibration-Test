package mn.steplab.vibration

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var vibrator: Vibrator
    private lateinit var frequency: Spinner
    private lateinit var duration: Spinner
    private lateinit var strength: Spinner
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        window.statusBarColor = Color.rgb(18, 28, 45)
        window.navigationBarColor = Color.rgb(18, 28, 45)
        buildUi()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(30), dp(24), dp(24))
            setBackgroundColor(Color.rgb(245, 247, 250))
        }

        page.addView(TextView(this).apply {
            text = "STEPLAB"
            textSize = 28f
            setTextColor(Color.rgb(22, 43, 72))
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }, matchWrap())

        page.addView(TextView(this).apply {
            text = "Чичиргээний тохиргоо"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(22))
        }, matchWrap())

        frequency = makeSpinner((1..10).map { "$it алхам/секунд" }, 4)
        duration = makeSpinner(listOf("10 секунд", "30 секунд", "60 секунд"), 1)
        strength = makeSpinner(listOf("Бага", "Дунд", "Их"), 1)

        addSetting(page, "Давтамж", frequency)
        addSetting(page, "Хугацаа", duration)
        addSetting(page, "Чичиргээний хүч", strength)

        val start = makeButton("▶  ЭХЛҮҮЛЭХ")
        page.addView(start, buttonParams())
        val stop = makeButton("■  ЗОГСООХ").apply {
            setBackgroundColor(Color.rgb(95, 105, 120))
        }
        page.addView(stop, buttonParams())

        status = TextView(this).apply {
            text = "Бэлэн"
            textSize = 14f
            setTextColor(Color.rgb(40, 90, 60))
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        }
        page.addView(status, matchWrap())

        start.setOnClickListener { startVibration() }
        stop.setOnClickListener {
            vibrator.cancel()
            status.text = "Зогслоо"
        }
        setContentView(page)
    }

    private fun startVibration() {
        if (!vibrator.hasVibrator()) {
            status.text = "Энэ утсанд чичиргээний мотор алга"
            return
        }
        val hz = frequency.selectedItemPosition + 1
        val totalMs = when (duration.selectedItemPosition) {
            0 -> 10_000L
            1 -> 30_000L
            else -> 60_000L
        }
        val amplitude = when (strength.selectedItemPosition) {
            0 -> 70
            1 -> 150
            else -> 255
        }
        val interval = 1000L / hz
        val pulse = minOf(65L, (interval * 0.4).toLong()).coerceAtLeast(1L)
        val count = (totalMs / interval).toInt().coerceAtLeast(1)
        val timings = LongArray(count * 2)
        val amplitudes = IntArray(count * 2)
        for (i in 0 until count) {
            timings[i * 2] = pulse
            amplitudes[i * 2] = amplitude
            timings[i * 2 + 1] = (interval - pulse).coerceAtLeast(1L)
            amplitudes[i * 2 + 1] = 0
        }
        vibrator.cancel()
        vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
        status.text = "Ажиллаж байна · $hz импульс/секунд"
    }

    private fun addSetting(parent: LinearLayout, label: String, spinner: Spinner) {
        parent.addView(TextView(this).apply {
            text = label
            textSize = 15f
            setTextColor(Color.rgb(35, 48, 65))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(10), 0, dp(3))
        }, matchWrap())
        parent.addView(spinner, LinearLayout.LayoutParams(-1, dp(50)))
    }

    private fun makeSpinner(items: List<String>, selected: Int) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(selected)
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(28, 94, 164))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun buttonParams() = LinearLayout.LayoutParams(-1, dp(54)).apply {
        topMargin = dp(14)
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        vibrator.cancel()
        super.onDestroy()
    }
}
